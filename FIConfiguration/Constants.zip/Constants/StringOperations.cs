﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FIConfiguration.Constants
{
	public class StringOperations
	{

		//public string ConvertStringToJson(string )
		//{
		//}
	}
}